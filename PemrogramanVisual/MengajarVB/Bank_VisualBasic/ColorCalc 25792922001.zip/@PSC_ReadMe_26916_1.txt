Title: ColorCalc 2
Description: This is my second version of ColorCalc. It has 17 new advanced features including Sin, Cos, Tan, !, %, and sqrt. I am planning on making version 3 with even more functions and a better look!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=26916&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
